def smart():
    return "Hello, smartdocument.ai"
